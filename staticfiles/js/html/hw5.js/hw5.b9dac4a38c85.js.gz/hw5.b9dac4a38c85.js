let first_table = document.querySelector('.table');
let second_table = document.querySelector('.h_table');
let switcher = document.querySelector('.h_table');
alert(1);